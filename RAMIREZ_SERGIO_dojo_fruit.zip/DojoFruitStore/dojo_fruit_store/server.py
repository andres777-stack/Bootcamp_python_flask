from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    print(request.form)
    print(request.form['first_name'])
    print(request.form['apple'])
    count = int(request.form['apple']) + int(request.form['strawberry']) + int(request.form['raspberry'])
    print("Cargo: " + request.form['first_name'] + ' ' + request.form['last_name'] + ' ' + "Por: ", count)
    cantidad_manzana = request.form['apple']
    cantidad_strawberry = request.form['strawberry']
    cantidad_raspberry = request.form['raspberry']
    nombre = request.form['first_name']
    apellido = request.form['last_name']
    rut_estu = request.form['student_id']
    return render_template("checkout.html", cm = cantidad_manzana, cs = cantidad_strawberry, cr = cantidad_raspberry, nom = nombre, ap = apellido, ci = rut_estu)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    